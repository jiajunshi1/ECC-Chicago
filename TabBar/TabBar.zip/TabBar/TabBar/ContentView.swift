//
//  ContentView.swift
//  TabBar
//
//  Created by 56GOParticipant on 6/26/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            TabOne()
                .tabItem {
                    Image(systemName: "house")
                    Text ("home")
                }
            
            TabTwo()
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text ("search")
                }
            
            TabThree()
                .tabItem {
                    Image(systemName: "person.crop.circle")
                    Text ("Profile")
                }
        }
        
    }
}

#Preview {
    ContentView()
}
