//
//  TabBarApp.swift
//  TabBar
//
//  Created by 56GOParticipant on 6/26/25.
//

import SwiftUI

@main
struct TabBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
