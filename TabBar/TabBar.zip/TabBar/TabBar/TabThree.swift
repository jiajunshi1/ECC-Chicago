//
//  TabThree.swift
//  TabBar
//
//  Created by 56GOParticipant on 6/26/25.
//

import SwiftUI

struct TabThree: View {
    var body: some View {
        Text("Screen Three")
            .fontWeight(.heavy)
            .foregroundColor(Color.black)
    }
}

#Preview {
    TabThree()
}
