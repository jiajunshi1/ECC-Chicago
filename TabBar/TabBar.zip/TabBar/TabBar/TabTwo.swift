//
//  TabOne.swift
//  TabBar
//
//  Created by 56GOParticipant on 6/26/25.
//

import SwiftUI

struct TabTwo: View {
    var body: some View {
        Text("Screen two")
            .fontWeight(.heavy)
            .foregroundColor(Color.blue)
    }
}

#Preview {
    TabTwo()
}
