//
//  TabOne.swift
//  TabBar
//
//  Created by 56GOParticipant on 6/26/25.
//

import SwiftUI

struct TabOne: View {
    var body: some View {
        Text("Screen One")
            .fontWeight(.heavy)
            .foregroundColor(Color.red)
    }
}

#Preview {
    TabOne()
}
